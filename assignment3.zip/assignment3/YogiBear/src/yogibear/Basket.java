
package yogibear;

import java.awt.Image;


public class Basket extends Sprite{
    
    public Basket(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
}

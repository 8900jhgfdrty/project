
package yogibear;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class YogiBearGUI {
    private JFrame frame;
    private GamePlay gameArea;

    public YogiBearGUI() {

        frame = new JFrame("Yogi Bear");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        gameArea = new GamePlay();
        frame.getContentPane().add(gameArea);        
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                // Show a confirmation dialog when the user tries to close the window
                int result = JOptionPane.showConfirmDialog(frame, 
                    "Do you want to exit?", 
                    "Exit Confirmation", 
                    JOptionPane.YES_NO_OPTION);
                if (result == JOptionPane.YES_OPTION) {
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.dispose();
                }
            }
        });
        JMenuBar menuBar = new JMenuBar();
        JMenu menuGame = new JMenu("Game");
        menuBar.add(menuGame);
        JMenuItem newMenu = new JMenuItem("New Game");
        menuGame.add(newMenu);
        newMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                gameArea.setAllBasketCollected(0);
                gameArea.setLevelNum(0);
                gameArea.restart();
            }
        });
        JMenuItem highScores = new JMenuItem("High scores");
        menuGame.add(highScores);

        highScores.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
        try {
            HighScores highScores = new HighScores();
            ArrayList<HighScore> topScores = highScores.getHighScores();
            String ranking = "";
            for (int i = 0; i < topScores.size(); i++) {
                ranking += (i + 1) + ". " + topScores.get(i).toString() + "\n";
            } 
            JOptionPane.showMessageDialog(frame, ranking, "Top 10 Scores", JOptionPane.PLAIN_MESSAGE);
        } 
       catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error retrieving scores", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});
        
        frame.setJMenuBar(menuBar);
        frame.setPreferredSize(new Dimension(800, 600));
        frame.setResizable(false);
        frame.pack();
        frame.setVisible(true);
    }
     
    }
    
    


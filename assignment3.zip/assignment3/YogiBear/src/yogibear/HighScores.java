
package yogibear;

import java.sql.*;
import java.util.ArrayList;

public class HighScores {
    private Connection connection;

    public HighScores() throws SQLException {
        // Initialize the database connection
        String url = "jdbc:mysql://localhost:3306/ROOT"; // URL to connect to the database
        String username = "root"; // Database username
        String password = "root"; // Database password

        // Establish the connection
        this.connection = DriverManager.getConnection(url, username, password);
    }

public void saveHighScore(String playerName, int score) throws SQLException {
    // Check if the player name already exists
    String checkQuery = "SELECT score FROM high_scores WHERE playerName = ?";
    try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
        checkStmt.setString(1, playerName);
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            int existingScore = rs.getInt("score");
            if (score > existingScore) {
                String updateQuery = "UPDATE high_scores SET score = ? WHERE playerName = ?";
                try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                    updateStmt.setInt(1, score);
                    updateStmt.setString(2, playerName);
                    updateStmt.executeUpdate();
                }
            }
        } else {
            String insertQuery = "INSERT INTO high_scores (playerName, score) VALUES (?, ?)";
            try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                insertStmt.setString(1, playerName);
                insertStmt.setInt(2, score);
                insertStmt.executeUpdate();
            }
        }
    }
}


    public ArrayList<HighScore> getHighScores() throws SQLException {
        ArrayList<HighScore> scores = new ArrayList<>();
        String query = "SELECT playerName, score FROM high_scores ORDER BY score DESC LIMIT 10";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                scores.add(new HighScore(rs.getString("playerName"), rs.getInt("score")));
            }
        }
        return scores;
    }
}

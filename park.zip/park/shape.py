# name:Lu Yingjie  and neptune :AF35AN
import turtle as t




def nSidedShape(sides, length):
    angle = 360 / sides
    for i in range(sides):
        t.fd(length)
        t.right(angle)


def position(x, y):
    t.penup()
    t.goto(x, y)
    t.pendown()


def grass():
    position(-400, -300)
    t.fillcolor("green")
    t.begin_fill()
    for i in range(4):
        if i % 2 == 0:
            t.fd(800)
            t.left(90)
        else:
            t.fd(300)
            t.left(90)
    t.end_fill()


def sun():
    position(-300, 200)
    t.fillcolor("red")
    t.begin_fill()
    t.circle(40)
    t.end_fill()


def cloud():
    t.seth(180)
    for i in range(2):
        if i == 0:

            t.right(180)
            position(-200, 150)

        else:
            position(50, 170)
            t.left(60)
        t.fillcolor("white")
        t.begin_fill()
        t.right(50)
        t.circle(50, 90)
        t.right(90)
        t.circle(50, 90)
        t.right(30)
        t.circle(20, 180)
        t.right(30)
        t.circle(40, 80)
        t.circle(40, -70)
        t.right(40)
        t.circle(60, 100)
        t.right(90)
        t.circle(23, -20)
        t.circle(23, 180)
        t.end_fill()


def duck():
    position(0, 0)
    t.fillcolor("yellow")
    t.begin_fill()
    t.circle(20)
    position(20, -45)
    t.circle(30)
    t.end_fill()
    position(6, 10)
    t.fillcolor("black")
    t.begin_fill()
    t.circle(5)
    t.end_fill()

    t.seth(-50)
    position(0, 0)
    t.fillcolor("red")
    t.begin_fill()
    nSidedShape(3, 10)
    t.end_fill()
    t.seth(0)
    position(10, -50)
    t.fillcolor("red")
    t.begin_fill()
    nSidedShape(3, 15)
    t.end_fill()
    t.seth(0)
    position(50, -60)
    t.fillcolor("red")
    t.begin_fill()
    nSidedShape(3, 15)
    t.end_fill()


def guard():
    position(-395, -300)
    for i in range(20):
        t.fillcolor("orange")
        t.begin_fill()
        t.seth(90)
        t.fd(55)
        t.right(30)
        t.fd(20)
        t.right(120)
        t.fd(20)
        t.right(30)
        t.fd(55)
        t.left(90)
        t.fd(-20)
        t.end_fill()
        t.fd(40)
    for j in range(2):
        position(-400, -265 - j * 25)
        t.fillcolor("orange")
        t.begin_fill()
        for i in range(4):
            if i % 2 == 0:
                t.fd(800)
                t.left(90)
            else:
                t.fd(15)
                t.left(90)
        t.end_fill()
        for i in range(20):
            position(-385 + i * 40, -262 - j * 25)
            t.fillcolor("black")
            t.begin_fill()
            t.circle(3)
            t.end_fill()


def sheep(x):
    position(-180 + x, -200)
    t.begin_fill()
    t.fillcolor("#FFFFC0")
    t.seth(-50)
    t.circle(35, 90)
    t.seth(-50)
    t.circle(20, 90)
    t.seth(-50)
    t.circle(35, 105)
    t.circle(35, -5)
    t.seth(0)
    t.circle(20, 120)
    t.seth(10)
    t.circle(35, 130)
    t.seth(10)
    t.circle(10, 180)
    t.seth(80)
    t.circle(30, 120)
    t.seth(100)
    t.circle(20, 130)
    t.right(90)
    t.circle(40, -20)
    t.circle(40, 110)
    t.circle(40, -10)
    t.right(75)
    t.circle(40, 130)
    t.right(110)
    t.circle(15, 150)
    t.right(120)
    t.circle(25, 150)
    t.right(100)
    t.circle(30, 150)
    t.end_fill()
    position(-190 + x, -100)
    t.begin_fill()
    t.fillcolor("#FFC0C0")
    t.seth(-40)
    t.circle(35, 90)
    t.circle(35, -10)
    t.seth(-60)
    t.circle(15, 120)
    t.seth(-60)
    t.circle(20, 120)
    t.circle(20, -30)
    t.seth(-80)
    t.circle(20, 80)
    t.circle(-15, 195)
    t.circle(-40, 80)
    t.seth(-70)
    t.circle(-100, 20)
    t.circle(-40, 90)
    t.circle(-100, 10)
    t.circle(-40, 110)
    t.circle(40, 30)
    t.circle(50, -65)
    t.circle(15, -210)
    t.circle(-40, -50)
    t.end_fill()
    
    for i in range(2): 
        t.seth(90)
        position(-160 + i * 40 + x, -130)
        t.begin_fill()
        t.fillcolor("black")
        for j in range(2):
            t.circle(5, 180)
            t.fd(5)
        t.end_fill()
    for i in range(2): 
        t.seth(0)
        t.color("#FF2080")
        position(-170 + i * 55 + x, -155)
        t.begin_fill()
        t.fillcolor("#FF2080")
        for j in range(2):
            t.circle(5, 180)
            t.fd(5)
        t.end_fill()

    position(-158 + x, -148)
    t.color("black")
    t.begin_fill()
    t.fillcolor("#FF4060")
    t.seth(-50)
    t.circle(10, 90)
    t.seth(-50)
    t.circle(10, 90)
    t.circle(10, -50)
    t.seth(90)
    t.circle(10, -90)
    t.right(40)
    t.circle(10, -55)
    t.end_fill()

    for i in range(3):
        position(-190 + i * 60 + x, -200)
        t.color("black")
        t.begin_fill()
        t.fillcolor("#FFC0C0")
        t.seth(-30)
        t.circle(15, 60)
        t.seth(-30)
        t.circle(15, 60)
        t.circle(15, -20)
        t.seth(110)
        t.circle(15, -90)
        t.right(40)
        t.circle(15, -90)
        t.end_fill()



def tree():
    position(-280, -180)
    t.pensize(30)
    t.color("orange")
    t.seth(90)
    t.fd(40)
    t.pensize(1)
    for i in range(5):
        position(-365 + i * 10, -140 + i * 45)
        t.begin_fill()
        t.color("black")
        t.fillcolor("#7FFF00")
        t.seth(0)
        t.fd(180 - i * 20)
        t.right(60)
        t.fd(-50)
        t.left(60)
        t.fd(-130 + i * 20)
        t.left(60)
        t.fd(-50)
        t.end_fill()
    position(-300, 110)
    t.seth(10)
    t.pensize(1)
    t.color("yellow")
    t.begin_fill()
    t.fillcolor("yellow")
    for i in range(4):
        t.fd(20)
        t.left(70)
        t.fd(20)
        t.right(160)
    t.end_fill()



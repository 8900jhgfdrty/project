# name:Lu Yingjie  and neptune :AF35AN
import turtle as t

from shape import *

t.setup(800, 600)
# t.hideturtle()
t.bgcolor("#87CEEB")
t.pensize(1)
t.speed(0)
grass()
sun()
cloud()
duck()
guard()
sheep(300)
tree()
t.done()
